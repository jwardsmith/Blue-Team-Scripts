class UnsupportedRuntimeError(RuntimeError):
    pass


class UnsupportedFormatError(ValueError):
    pass


class UnsupportedArchError(ValueError):
    pass


class UnsupportedOSError(ValueError):
    pass
